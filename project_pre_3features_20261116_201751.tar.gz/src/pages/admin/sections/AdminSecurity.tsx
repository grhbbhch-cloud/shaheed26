import React, { useEffect, useState } from 'react';
import { ShieldCheck } from 'lucide-react';
import { AdminCard, AdminPanelHeader } from '../../../components/admin/AdminSharedUI';
import { useAdmin } from '../../../context/AdminContext';
import type { AllSettings } from '../../../types/platform';

export function AdminSecurity() {
  const { settings, saveCategory, resetCategory } = useAdmin();
  const [sec, setSec] = useState<AllSettings['security'] | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (settings) setSec(structuredClone(settings.security));
  }, [settings]);

  if (!settings || !sec) return null;

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveCategory('security', sec, 'تحديث إعدادات الأمان والحماية');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <AdminPanelHeader
        title="الأمان والحماية"
        subtitle="إدارة سياسة الجلسات، حماية تسجيل الدخول برمزي المالك، وتحديد الحد الأقصى للمحاولات"
        onSave={handleSave}
        onReset={() => resetCategory('security')}
        saving={saving}
      />

      <div className="space-y-5">
        <AdminCard title="حالة حماية بوابة المالك">
          <div className="flex items-start gap-3 p-3.5 rounded-xl border border-[#E8E0D0] bg-[#F7F4EC] text-[#171717] text-xs">
            <ShieldCheck size={18} className="shrink-0 mt-0.5 text-[#8C6A2F]" />
            <div>
              <div className="font-bold">المصادقة الثنائية للمالك مفعّلة على الخادم</div>
              <p className="mt-1 text-neutral-700 leading-relaxed">
                لا يتم قبول الدخول إلا بالتحقق من رمزي الدخول معاً على الخادم عبر تجزئة SHA-256 ومقارنة آمنة للوقت،
                مع جلسة مشفرة بتوقيع HMAC داخل ملف تعريف HttpOnly لا يمكن قراءته من المتصفح.
              </p>
            </div>
          </div>
        </AdminCard>

        <AdminCard title="سياسات الجلسة ومنع التخمين">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                مدة الجلسة (بالدقائق)
              </label>
              <input
                type="number"
                min={15}
                max={43200}
                value={sec.sessionTimeoutMinutes}
                onChange={(e) => setSec({ ...sec, sessionTimeoutMinutes: Number(e.target.value) })}
                className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-xs tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                الحد الأقصى لمحاولات الدخول الفاشلة
              </label>
              <input
                type="number"
                min={3}
                max={50}
                value={sec.maxLoginAttempts}
                onChange={(e) => setSec({ ...sec, maxLoginAttempts: Number(e.target.value) })}
                className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-xs tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                مدة الحظر المؤقت (بالدقائق)
              </label>
              <input
                type="number"
                min={1}
                max={1440}
                value={sec.lockoutMinutes}
                onChange={(e) => setSec({ ...sec, lockoutMinutes: Number(e.target.value) })}
                className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-xs tabular-nums"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-6">
            <label className="inline-flex items-center gap-2 text-xs font-bold cursor-pointer">
              <input
                type="checkbox"
                checked={sec.ipRateLimitEnabled}
                onChange={(e) => setSec({ ...sec, ipRateLimitEnabled: e.target.checked })}
                className="accent-[#B08D45]"
              />
              <span>تفعيل تحديد معدل المحاولات حسب عنوان الشبكة (Rate Limit)</span>
            </label>
          </div>
        </AdminCard>
      </div>
    </div>
  );
}
