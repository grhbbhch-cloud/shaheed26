import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { getPublicSettings, UPLOADS_DIR } from './server/db.ts';
import { registerRoutes } from './server/routes.ts';

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

async function startServer() {
  const app = express();
  app.set('trust proxy', 1);

  // JSON parser (skip raw chunk uploads which use express.raw inside route)
  app.use((req, res, next) => {
    if (req.path.includes('/api/admin/uploads/') && req.path.includes('/chunk/')) {
      next();
      return;
    }
    express.json({ limit: '50mb' })(req, res, next);
  });

  // Serve persistent uploaded media, thumbnails, renditions, fonts, favicons
  app.use(
    '/uploads',
    express.static(UPLOADS_DIR, {
      acceptRanges: true,
      maxAge: '7d',
      fallthrough: false,
    })
  );

  // Dynamic favicon endpoint so browser tab updates reliably
  app.get('/favicon.ico', (_req, res) => {
    try {
      const pub = getPublicSettings();
      const fav = pub.identity?.faviconUrl;
      if (fav && fav.startsWith('/uploads/')) {
        const local = path.join(UPLOADS_DIR, fav.replace(/^\/uploads\//, ''));
        if (fs.existsSync(local)) {
          res.setHeader('Cache-Control', 'no-cache');
          res.sendFile(local);
          return;
        }
      }
      const staticPublicFav = path.resolve(process.cwd(), 'public/favicon.ico');
      if (fs.existsSync(staticPublicFav)) {
        res.setHeader('Cache-Control', 'no-cache');
        res.sendFile(staticPublicFav);
        return;
      }
    } catch {
      // ignore
    }
    // Clean minimal gold geometric SVG fallback favicon
    res.setHeader('Content-Type', 'image/svg+xml');
    res.setHeader('Cache-Control', 'no-cache');
    res.send(
      `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="12" fill="#B08D45"/><path d="M32 10l5.5 14.5L52 30l-14.5 5.5L32 50l-5.5-14.5L12 30l14.5-5.5z" fill="#FFFFFF"/></svg>`
    );
  });

  // Register all API routes
  registerRoutes(app);

  // Error handler for upload / JSON errors
  app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
    const status = err?.status || 500;
    res.status(status).json({ error: err?.message || 'حدث خطأ غير متوقع في الخادم' });
  });

  function injectMetaIntoHtml(html: string): string {
    try {
      const pub = getPublicSettings();
      const title = pub.identity.browserTitle || pub.identity.siteName || 'أرشيف الشهيد';
      const desc = pub.identity.metaDescription || '';
      const favUrl = pub.identity.faviconUrl
        ? `${pub.identity.faviconUrl}?v=${pub.identity.faviconVersion || 1}`
        : `/favicon.ico?v=${pub.identity.faviconVersion || 1}`;
      const ogImg = pub.identity.defaultShareImage || '';

      let out = html.replace(/<title>[\s\S]*?<\/title>/i, `<title>${escapeHtml(title)}</title>`);
      out = out.replace(
        /<meta name="description" content="[^"]*"\s*\/?>/i,
        `<meta name="description" content="${escapeHtml(desc)}" />`
      );
      out = out.replace(
        /<meta property="og:title" content="[^"]*"\s*\/?>/i,
        `<meta property="og:title" content="${escapeHtml(title)}" />`
      );
      out = out.replace(
        /<meta property="og:description" content="[^"]*"\s*\/?>/i,
        `<meta property="og:description" content="${escapeHtml(desc)}" />`
      );
      const favTag = `<link rel="icon" href="${escapeHtml(favUrl)}" />`;
      const ogImgTag = ogImg ? `<meta property="og:image" content="${escapeHtml(ogImg)}" />` : '';
      out = out.replace('</head>', `  ${favTag}\n  ${ogImgTag}\n  </head>`);
      return out;
    } catch {
      return html;
    }
  }

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    app.use('*', async (req, res, next) => {
      if (req.originalUrl.startsWith('/api/') || req.originalUrl.startsWith('/uploads/')) {
        next();
        return;
      }
      try {
        const indexPath = path.resolve(process.cwd(), 'index.html');
        let html = fs.readFileSync(indexPath, 'utf8');
        html = await vite.transformIndexHtml(req.originalUrl, html);
        html = injectMetaIntoHtml(html);
        res.status(200).set({ 'Content-Type': 'text/html; charset=utf-8' }).end(html);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir, { index: false }));
    app.get('*', (req, res, next) => {
      if (req.originalUrl.startsWith('/api/') || req.originalUrl.startsWith('/uploads/')) {
        next();
        return;
      }
      const indexPath = path.join(distDir, 'index.html');
      if (!fs.existsSync(indexPath)) {
        res.status(500).send('Application build missing. Run npm run build.');
        return;
      }
      const html = injectMetaIntoHtml(fs.readFileSync(indexPath, 'utf8'));
      res.status(200).set({ 'Content-Type': 'text/html; charset=utf-8' }).end(html);
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Alharbi Media server running on http://0.0.0.0:${PORT}`);
  });
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

startServer();
